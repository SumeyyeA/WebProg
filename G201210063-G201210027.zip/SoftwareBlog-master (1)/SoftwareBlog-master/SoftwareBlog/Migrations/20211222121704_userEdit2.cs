﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SoftwareBlog.Migrations
{
    public partial class userEdit2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
