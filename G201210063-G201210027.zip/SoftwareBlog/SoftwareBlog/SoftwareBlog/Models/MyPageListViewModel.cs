﻿using Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoftwareBlog.Models
{
    public class MyPageListViewModel
    {
        public List<BlogPost> MyPosts { get; set; }
        public UserDetailsModel UserDetails { get; set; }
    }
}
